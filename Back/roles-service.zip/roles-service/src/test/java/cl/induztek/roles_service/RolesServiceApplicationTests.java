package cl.induztek.roles_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RolesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
